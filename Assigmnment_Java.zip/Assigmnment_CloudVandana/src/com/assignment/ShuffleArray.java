package com.assignment;

import java.util.*;

public class ShuffleArray {
	int a[]= {1, 2, 3, 4, 5, 6, 7};
	Random random = new Random();
	public void shuffleMethod() {
		int r=0;
		for(int i=0;i<a.length;i++) {
				r=random.nextInt(7);
				int temp =a[r];
				a[r]=a[i];
				a[i]=temp;
		}
		for(int i=0;i<a.length;i++) {
			System.out.print(a[i]+" ");
		}
	
   }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ShuffleArray shuff =new ShuffleArray();
		shuff.shuffleMethod();

	}

}
