package com.assignment;

import java.util.Scanner;

public class RomanToInt {
	int value(char r) {
		switch(r) {
			case 'I': 
				return 1;
			case 'V': 
				return 5;  
			case 'X':
				return 10;
			case 'L': 
				return 50; 
			case 'C': 
				return 100;
			case 'D':
				return 500; 
			case 'M':
				return 1000;  
            }              
		return -1;   

	    }
	 int convertRomanToInt(String s) {
		int total = 0;
		for (int i = 0; i < s.length(); i++) {
			int s1 = value(s.charAt(i));
			if (i + 1 < s.length()) {
				int s2 = value(s.charAt(i + 1));
				if (s1 >= s2) {
					total = total + s1;
				} else {
					total = total - s1;
				}
			} else {
				total = total + s1;
			}
		}
		return total;
	}

 

	public static void main(String args[]) {
		RomanToInt ob = new RomanToInt();
		Scanner scan =new Scanner(System.in);
		System.out.println("Enter the Roman value:");
		String roman =scan.nextLine();
		System.out.println("Integer value is: " + ob.convertRomanToInt(roman));
	}
}

