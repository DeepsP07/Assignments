const arr = [34, 67, 43, 23, 1, 556, 8 ] 

function sortDesc(arr){
    for (let i = 0; i < arr.length - 1; i++){

        let swapped = false

        for (let j = 0; j < arr.length - i - 1; j++){
            // swapping the elements
            if (arr[j] < arr[j+1]){
                let temp = arr[j]
                arr[j] = arr[j+1]
                arr[j+1] = temp
                swapped = true
            }
        }

        // if no elements are swapped
        // that means our array is sorted
        if(!swapped) break;
    }

    return arr
}

console.log("After Descending sort: ", sortDesc(arr))